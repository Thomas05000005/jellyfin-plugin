# Jellyfin Enhancer Plugin

## Description
This plugin enhances video and audio quality with upscaling options and AI-based algorithms for Jellyfin.

## Features
- Upscaling video to 4K or 8K
- Enhancing audio with Dolby Atmos
- AI-based super-resolution for video
- AI-based audio enhancement
- Configurable options for choosing enhancement algorithms
- Language selection between English and French
- Video color enhancement with Dolby Vision, HDR10, and HDR10+

## Installation
1. Download the plugin.
2. Run the install script to install dependencies:
    ```bash
    ./install.sh
    ```
3. Place the plugin in the Jellyfin plugins directory.
4. Restart Jellyfin server.
5. Configure the plugin through Jellyfin dashboard.

## Configuration
You can configure the enhancement options in the Jellyfin dashboard under the Enhancer Plugin settings.

## Requirements
- Jellyfin server
- FFmpeg installed on the server
- OpenCV and TensorFlow for AI-based processing

## License
MIT License