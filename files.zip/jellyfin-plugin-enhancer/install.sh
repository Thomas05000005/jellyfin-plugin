#!/bin/bash

# Update package list and install dependencies
sudo apt update
sudo apt install -y ffmpeg python3-pip

# Install Python packages for AI processing
pip3 install opencv-python-headless tensorflow

echo "Dependencies installed successfully."