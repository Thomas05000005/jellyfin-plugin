using System.Diagnostics;
using System.Threading.Tasks;

namespace Jellyfin.Plugin.Enhancer
{
    public class FFmpegProcessor
    {
        private readonly PluginConfiguration _config;

        public FFmpegProcessor(PluginConfiguration config)
        {
            _config = config;
        }

        public async Task<string> EnhanceVideo(string inputPath, string outputPath)
        {
            var resolution = _config.VideoResolution;
            var bitrate = _config.VideoBitrate;
            var codec = _config.VideoCodec;
            var format = _config.ContainerFormat;
            var quality = _config.EncodingQuality;
            var colorFormat = _config.VideoColorFormat;

            var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "ffmpeg",
                    Arguments = $"-i {inputPath} -vf scale={resolution},format=yuv420p10le -b:v {bitrate}k -c:v {codec} -crf {quality} -color_primaries bt2020 -color_trc smpte2084 -colorspace bt2020nc -metadata:s:v color_range=full -metadata:s:v mastering_display=G(0,0,BT2020),R(0,0,BT2020),B(0,0,BT2020),WP(0,0,BT2020),L(10000000,0.005) -metadata:s:v light_level=1000,100 {outputPath}.{format}",
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                }
            };

            process.Start();
            await process.WaitForExitAsync();
            return outputPath;
        }

        public async Task<string> EnhanceAudio(string inputPath, string outputPath)
        {
            var sampleRate = _config.AudioSampleRate;
            var bitrate = _config.AudioBitrate;
            var format = _config.ContainerFormat;
            var audioFormat = _config.AudioFormat;

            var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "ffmpeg",
                    Arguments = $"-i {inputPath} -ar {sampleRate} -b:a {bitrate}k -c:a {audioFormat} {outputPath}.{format}",
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                }
            };

            process.Start();
            await process.WaitForExitAsync();
            return outputPath;
        }
    }
}