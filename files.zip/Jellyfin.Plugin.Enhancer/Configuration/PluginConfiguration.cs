using MediaBrowser.Model.Plugins;

namespace Jellyfin.Plugin.Enhancer.Configuration
{
    public class PluginConfiguration : BasePluginConfiguration
    {
        public string Language { get; set; } = "en";
        public bool EnableVideoEnhancement { get; set; } = true;
        public bool EnableAudioEnhancement { get; set; } = true;
        public string VideoEnhancementAlgorithm { get; set; } = "FFmpeg";
        public string AudioEnhancementAlgorithm { get; set; } = "Dolby";
        public string AIModelType { get; set; } = "Basic";
        public string VideoResolution { get; set; } = "4K";
        public string VideoBitrateMode { get; set; } = "constant";
        public string VideoQuality { get; set; } = "high";
        public string VideoCodec { get; set; } = "x265";
        public int EncodingQuality { get; set; } = 23;
        public string AudioBitrateMode { get; set; } = "constant";
        public string AudioQuality { get; set; } = "high";
        public int AudioSampleRate { get; set; } = 48000;
        public string ContainerFormat { get; set; } = "mkv";
        public string AudioFormat { get; set; } = "dolby-atmos";
        public string VideoColorFormat { get; set; } = "dolby-vision";
        public string FileInfo { get; set; }
        public double EstimatedProcessingTime { get; set; }
        public double VideoQualityImprovement { get; set; }
        public double AudioQualityImprovement { get; set; }
        public string SelectedFilePath { get; set; }
    }
}